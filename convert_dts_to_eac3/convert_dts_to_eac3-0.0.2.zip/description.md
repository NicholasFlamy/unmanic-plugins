
---

##### Links:

- [Support](https://unmanic.app/discord)

---

##### Description:

- This plugin converts all 6 channel (or greater) dts & truehd audio streams to eac3
- The original stream(s) is(are) no longer present at the conclusion of this plugin's operation
---

##### Documentation:

For information on the available encoder settings:
- [FFmpeg - High Quality Audio Encoding](https://trac.ffmpeg.org/wiki/Encode/HighQualityAudio)
--- 

##### Config description:

bit_rate - set the aggregate bit rate for all audio streams.  The default setting is 640k

None

