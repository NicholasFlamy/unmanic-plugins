# Remove audio streams with number of channels greater than specified max

plugin for [Unmanic](https://github.com/Unmanic)
