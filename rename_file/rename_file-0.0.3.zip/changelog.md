
**<span style="color:#56adda">0.0.3</span>**
- added renaming of related files (same basename with other extensions, .e.g., .srt, .nfo, etc)

**<span style="color:#56adda">0.0.2</span>**
- added 2nd option of replacing sections of filename with resuls from transcode
- this is an option instead of simply appending with ffprobe fields
- governed by 1st checkbox option

**<span style="color:#56adda">0.0.1</span>**
- Initial version
