
**<span style="color:#56adda">0.0.4</span>**
- fix stream_encoding list

**<span style="color:#56adda">0.0.3</span>**
- add '-ac' parameter to encoder to avoid incompatible channel layout error

**<span style="color:#56adda">0.0.2</span>**
- fix normalise check to use `aac` as ffmpeg writes only `aac` to codec_name

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- based on normalise_aac from Josh.5
