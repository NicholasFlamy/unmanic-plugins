
**<span style="color:#56adda">0.0.4</span>**
- add result text to error messages
- documentation updates

**<span style="color:#56adda">0.0.3</span>**
- add unmanic_notifier shell script
- option to run a custom command after the notificiation
- status message (successful or unsuccessful) is passed to the script
- file name of the video file is passed to the script
- add "unmanic://" to the /config/apprise_config.txt to use this
- requires a custom shell script that you provide located in /config/unmanic_notifier.sh

**<span style="color:#56adda">0.0.2</span>**
- license updates
- status message updates

**<span style="color:#56adda">0.0.1</span>**
- Initial version
