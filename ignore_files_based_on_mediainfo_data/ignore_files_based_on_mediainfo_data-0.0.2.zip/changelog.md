
**<span style="color:#56adda">0.0.2</span>**
- updated requirements.txt to remove version numbers so compatible with latest or staging tags (different pythong versions)

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- Mediainfo version of Ignore Files based on metadata
