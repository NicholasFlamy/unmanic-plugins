
**<span style="color:#56adda">0.0.2</span>**
- set stream to be labeled with metadata as stream returned from astreams calculation

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- based on reorder_audio_streams2 v0.0.24
