
Enter ffprobe metadata field and associated value to search for during processing.

Any files with matching ffprobe metadata keys matching the specified value will have those streams removed during processing.
---

##### Links:

- [Support](https://unmanic.app/discord)

---

##### Example:

###### <span style="color:magenta">metadata field to search</span>
```
codec_name
```

###### <span style="color:magenta">metadata value (substring) to check</span>
```
hdmv_pgs_subtitle
```
