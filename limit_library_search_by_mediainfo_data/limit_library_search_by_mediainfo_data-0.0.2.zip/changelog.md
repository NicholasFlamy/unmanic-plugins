
**<span style="color:#56adda">0.0.2</span>**
- removed version numbers from requirements.txt to make compatible with both latest and staging tags (different pythong versions)

**<span style="color:#56adda">0.0.1</span>**
- Initial version
- Mediainfo version of Limit Library Search by FFprobe Data
